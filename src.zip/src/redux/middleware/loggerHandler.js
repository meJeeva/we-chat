


export const loggerHandler = (store) => (next) => (action) => {
    const result = next(action);
    return result;
}