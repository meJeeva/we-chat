import { configureStore } from '@reduxjs/toolkit'
import authReducers from '../redux/slices/authSlice'
import { loggerHandler } from './middleware/loggerHandler';

const store = configureStore({
    reducer: {
        auth: authReducers
    },
    middleware: (gM) => gM().concat(loggerHandler)
});

export default store;


