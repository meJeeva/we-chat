import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { GET, POST } from "../../services/Http";
import { API } from "../../services/Api/api";

const initialState = {
    accessToken: null,
    email: null,
    firstName: null,
    gender: null,
    id: null,
    image: null,
    lastName: false,
    refreshToken: null,
    username: null,
    loading: false,
    error: null,
    userDetails: {}
};

const loginAPI = createAsyncThunk('auth/login', async (req, thunkAPI) => {
    try {
        let response = await POST(API.login, { ...req, expiresInMins: 1 });
        return response.data;
    } catch (error) {
        console.log(error);
        return thunkAPI.rejectWithValue(error)
    }
});

const getUserDetailsAPI = createAsyncThunk('auth/getUserDetails', async (params, thunkAPI) => {
    try {
        let response = await GET(API.userDetails);
        return response.data;
    } catch (error) {
        console.log('error in getUserDetails', error);
        return thunkAPI.rejectWithValue(error)
    }
});

const refreshTokenAPI = createAsyncThunk('auth/refreshToken', async (req, thunkAPI) => {
    try {
        const response = await POST(API.refreshToken, req);
        console.log('refreshTokenAPI response', response)
        return response.data;
    } catch (error) {
        console.log('error in refreshTokenAPI', error);
        return thunkAPI.rejectWithValue(error);
    }
})

const auth = createSlice({
    name: "auth",
    initialState,
    reducers: {
        logout: (state, action) => {
            state.accessToken = null;
            state.email = null;
            state.error = null;
            state.firstName = null;
            state.gender = null;
            state.id = null;
            state.image = null;
            state.loading = false;
            state.refreshToken = null;
            state.username = null;
        }
    },
    extraReducers: (builder) => {
        builder
            .addCase(loginAPI.pending, (state, _) => {
                state.loading = true;
            })
            .addCase(loginAPI.fulfilled, (state, action) => {
                console.log('final data', action)
                let data = action.payload;
                state.accessToken = data.accessToken;
                state.email = data.email;
                state.firstName = data.firstName;
                state.gender = data.gender;
                state.id = data.id;
                state.image = data.image
                state.lastName = data.lastName;
                state.refreshToken = data.refreshToken;
                state.username = data.username;
                state.loading = false;
                state.error = null
            })
            .addCase(loginAPI.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error || action.payload.error
            })

        builder
            .addCase(getUserDetailsAPI.pending, (state, _) => {
                state.loading = true;
            })
            .addCase(getUserDetailsAPI.fulfilled, (state, action) => {
                let data = action.payload;
                state.userDetails = data;
                state.loading = false;
                state.error = null;
            })
            .addCase(getUserDetailsAPI.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error || action.payload.erro
            })


        builder
            .addCase(refreshTokenAPI.pending, (state, _) => {
                state.loading = true;
            })
            .addCase(refreshTokenAPI.fulfilled, (state, action) => {
                let data = action.payload;
                state.refreshToken = data.refreshToken;
                state.accessToken = data.accessToken;
                state.loading = false;
                state.error = null;
            })
            .addCase(refreshTokenAPI.rejected, (state, action) => {
                state.loading = false;
                state.error = action.error || action.payload.erro
            })
    },
    selectors: {

    }
});


export default auth.reducer;
export const { logout } = auth.actions;
export {
    loginAPI,
    getUserDetailsAPI,
    refreshTokenAPI
}