import Axios from 'axios'
import axiosRetry from 'axios-retry'
import store from '../../redux/store';
import { refreshTokenAPI } from '../../redux/slices/authSlice';

const BASE_URL = 'https://dummyjson.com/';

const api = Axios.create({
    baseURL: BASE_URL,
    timeout: 10000,
    headers: {
        'Content-Type': 'application/json'
    }
});

api.interceptors.request.use(
    (config) => {
        let token = '';
        if (token) config.headers['Authorization'] = `Bearer ${token}`;
        return config;
    },
    (err) => {
        return err;
    }
);

api.interceptors.response.use(
    (res) => {
        return res;
    },
    async (error) => {
        const originalErr = error.config;

        if (error.response.status === 401 && !originalErr._retry) {
            originalErr._retry = true;
            const refreshToken = store.getState().auth.refreshToken;
            let request = {
                refreshToken,
                expiresInMins: 1
            }
            const { payload } = await store.dispatch(refreshTokenAPI(request));
            console.log('store.dispatch(refreshTokenAPI(request))', payload)

            api.defaults.headers.common['Authorization'] = `Bearer ${payload.accessToken}`;
            originalErr.headers['Authorization'] = `Bearer ${payload.accessToken}`;

            return api(originalErr)
        }
        console.log('testttt', originalErr)
        return Promise.reject(error);
    }
);




export const createCancelToken = () => Axios.CancelToken.source();

const POST = async (path, data = {}, config = {}, cancelSource) => {
    return api.post(path, data, { ...config, cancelToken: cancelSource?.token })
};
const GET = async (path, params = {}, config = {}) => {
    return api.get(path, params, { ...config });
}
const PUT = async (path, data = {}, config = {}) => {
    return api.put(path, data, { ...config })
}
const DEL = async (path, params = {}, config = {}) => {
    return api.delete(path, params, { ...config });
}

export {
    POST,
    GET,
    PUT,
    DEL,
    BASE_URL
}