


const API = {
    login: 'auth/login',
    userDetails: 'auth/me',
    refreshToken: 'auth/refresh'
}


export {
    API
}