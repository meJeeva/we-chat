import { Alert, StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react'
import { Badge, Button, TextInput } from 'react-native-paper'
import { useDispatch } from 'react-redux';
import { loginAPI } from '../redux/slices/authSlice';

const Login = ({ navigation }) => {

  const [form, setForm] = useState({
    username: '',
    password: ''
  });

  const dispatch = useDispatch();

  const onHandleLogin = () => {
    dispatch(loginAPI(form))
      .unwrap()
      .then(() => {
        navigation.replace('Home')
      })
      .catch((error) => {
        Alert.alert('Login failed', error.message)
      })
  }

  return (
    <View style={{
      flex: 1,

    }}>
      <View style={{
        margin: 20,
        marginTop: '40%'
      }}>
        <Text style={{
          textAlign: 'center',
          fontSize: 20,
          marginBottom: 20
        }}>Login</Text>
        <TextInput
          value={form.username}
          mode='outlined'
          label={'userName'}
          onChangeText={(t) => setForm(p => ({ ...p, username: t }))}
        />
        <TextInput
          value={form.password}
          mode='outlined'
          label={'password'}
          onChangeText={(t) => setForm(p => ({ ...p, password: t }))}
        />
        <Button mode='outlined' style={{
          marginTop: 20
        }}
          onPress={onHandleLogin}
        >
          Submit
        </Button>
      </View>
    </View>
  )
}

export default Login

const styles = StyleSheet.create({})