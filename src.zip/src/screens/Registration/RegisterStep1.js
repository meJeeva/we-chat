import { StyleSheet, Text, View } from 'react-native'
import React, { useState } from 'react'
import { Button, TextInput } from 'react-native-paper'
import { useNavigation } from '@react-navigation/native';

const RegisterStep1 = () => {

    const [email, setEmail] = useState('');
    const [phoneno, setPhoneno] = useState('');

    const navigation = useNavigation();

    return (
        <View style={{
            flex: 1
        }}>
            <View style={{
                margin: 20,
                flexDirection: 'column',
                gap: 20,
                marginTop: 100
            }}>
                <Text style={{
                    textAlign: 'center'
                }}>PROCESS ONE</Text>
                <TextInput label={'email'} mode="outlined" value={email} onChangeText={setEmail} outlineColor='gray' activeOutlineColor='black' />
                <TextInput label={'phone'} mode="outlined" value={phoneno} onChangeText={setPhoneno} outlineColor='gray' activeOutlineColor='black' />
                <Button mode='contained-tonal' buttonColor='gray' textColor='white' onPress={() => {
                    let userRegisterDetails = {
                        email,
                        phoneno
                    }
                    navigation.navigate('RegisterStep2', { userRegisterDetails })
                }}>
                    Submit
                </Button>
            </View>
        </View>
    )
}

export default RegisterStep1

const styles = StyleSheet.create({})