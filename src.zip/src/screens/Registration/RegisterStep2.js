import { BackHandler, StyleSheet, Text, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { useNavigation, useRoute } from '@react-navigation/native'
import { Button, TextInput } from 'react-native-paper';

const RegisterStep2 = () => {
    const [OTP, setOTP] = useState('');
    const navigation = useNavigation();

    const userRegisterDetails = useRoute().params.userRegisterDetails;

    useEffect(() => {
        const subscription = BackHandler.addEventListener('hardwareBackPress', () => {
            navigation.goBack();
            return true
        });
        return () => subscription.remove();
    }, []);

    return (
        <View style={{
            flex: 1
        }}>
            <View style={{
                margin: 20,
                flexDirection: 'column',
                gap: 20,
                marginTop: 100
            }}>
                <Text style={{
                    textAlign: 'center'
                }}>PROCESS TWO</Text>
                <TextInput label={'OTP'} mode="outlined" value={OTP} onChangeText={setOTP} outlineColor='gray' activeOutlineColor='black' />
                <Button mode='contained-tonal' buttonColor='gray' textColor='white' onPress={() => {
                    navigation.navigate('RegisterStep3', { userRegisterDetails: { ...userRegisterDetails, OTP } })
                }}>
                    Submit
                </Button>
            </View>
        </View>
    )
}

export default RegisterStep2

const styles = StyleSheet.create({})