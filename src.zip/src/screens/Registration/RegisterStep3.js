import { View, Text } from 'react-native'
import React from 'react'
import { useRoute } from '@react-navigation/native';

const RegisterStep3 = () => {

    const userRegisterDetails = useRoute().params.userRegisterDetails;

    return (
        <View>
            <Text>RegisterStep3</Text>
        </View>
    )
}

export default RegisterStep3