import React, { useEffect, useState } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity, SafeAreaView, ScrollView, RefreshControl } from "react-native";
import { useDispatch, useSelector } from "react-redux";
import { getUserDetailsAPI, logout } from "../redux/slices/authSlice";

const Home = ({ navigation }) => {
    const [refresh, setRefresh] = useState(false);

    const user = useSelector((state) => state.auth);
    const dispatch = useDispatch();

    useEffect(() => {
        getUserDetails();
    }, []);

    let userData = user?.userDetails || {}

    const getUserDetails = () => dispatch(getUserDetailsAPI());

    const onHandleLogout = () => {
        dispatch(logout());
        navigation.replace('Login')
    }

    return (
        <SafeAreaView style={styles.container}>
            <ScrollView contentContainerStyle={styles.scroll} refreshControl={<RefreshControl onRefresh={() => {
                setRefresh(true);
                getUserDetails()
                setRefresh(false);
            }} refreshing={refresh} />}>

                <View style={styles.avatarContainer}>
                    <Image
                        source={
                            userData.image
                                ? { uri: userData.image }
                                : require("../assets/profile.jpg")
                        }
                        style={styles.avatar}
                    />
                </View>

                <Text style={styles.name}>
                    {userData.firstName} {userData.lastName}
                </Text>

                <Text style={styles.username}>
                    @{userData.username}
                </Text>

                <View style={styles.infoCard}>
                    <Text style={styles.label}>Email</Text>
                    <Text style={styles.value}>{userData.email}</Text>
                </View>

                <View style={styles.infoCard}>
                    <Text style={styles.label}>Gender</Text>
                    <Text style={styles.value}>{userData.gender}</Text>
                </View>

                <View style={styles.infoCard}>
                    <Text style={styles.label}>User ID</Text>
                    <Text style={styles.value}>{userData.id}</Text>
                </View>
                <TouchableOpacity style={styles.logoutButton} onPress={onHandleLogout}>
                    <Text style={styles.logoutText}>Logout</Text>
                </TouchableOpacity>

            </ScrollView>
        </SafeAreaView>
    );
};

export default Home;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#F9FAFB",
    },
    scroll: {
        paddingHorizontal: 20,
        paddingTop: 30,
    },
    avatarContainer: {
        alignSelf: "center",
        marginBottom: 20,
    },
    avatar: {
        width: 110,
        height: 110,
        borderRadius: 60,
        backgroundColor: "#eee",
    },
    name: {
        fontSize: 24,
        textAlign: "center",
        fontWeight: "bold",
        color: "#111",
    },
    username: {
        fontSize: 16,
        textAlign: "center",
        color: "#666",
        marginTop: 4,
        marginBottom: 20,
    },
    infoCard: {
        backgroundColor: "#fff",
        borderRadius: 12,
        padding: 16,
        marginVertical: 8,
        shadowColor: "#000",
        shadowOpacity: 0.05,
        shadowRadius: 6,
        elevation: 5,
    },
    label: {
        fontSize: 14,
        color: "#777",
    },
    value: {
        marginTop: 4,
        fontSize: 16,
        color: "#222",
        fontWeight: "600",
    },
    logoutButton: {
        marginTop: 30,
        backgroundColor: "#FF4757",
        paddingVertical: 14,
        borderRadius: 12,
    },
    logoutText: {
        textAlign: "center",
        color: "#fff",
        fontSize: 16,
        fontWeight: "600",
    },
});
