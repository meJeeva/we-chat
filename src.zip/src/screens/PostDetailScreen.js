import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const PostDetailScreen = () => {
    return (
        <View>
            <Text>PostDetailScreen</Text>
        </View>
    )
}

export default PostDetailScreen

const styles = StyleSheet.create({})