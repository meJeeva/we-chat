import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const CreatePostScreen = () => {
    return (
        <View>
            <Text>CreatePostScreen</Text>
        </View>
    )
}

export default CreatePostScreen

const styles = StyleSheet.create({})